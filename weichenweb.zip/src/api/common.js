import request from '@/utils/request'

// 文件上传
export function uploadFile(data) {
  return request({
    url: 'common/uploadFile',
    method: 'post',
    data
  })
}
