<template>
  <!-- 关联区域 -->
  <div class="formbox">
    <el-form :model="formMess">
      <!-- 广告主 -->
      <el-col :span="7">
        <el-input
          class="inline-input"
          v-model="formMess.sponsorName"
          placeholder="选择广告主"
          :trigger-on-focus="true"
          clearable
        >
        </el-input>
        <div class="dd">
          <select multiple @change="sponsorOnChageValue">
            <option v-for="(item, i) in selectItems" :value="i">
              {{ item.adName }}
            </option>
          </select>
        </div>
      </el-col>
      <!-- 品牌 -->
      <el-col :span="7">
        <el-input
          class="inline-input"
          v-model="formMess.bandName"
          placeholder="请输入品牌搜索"
          :trigger-on-focus="true"
          ref="id"
          clearable
          @input="searchOnChange"
        >
        </el-input>
        <div class="dd">
          <select multiple v-if="selectBrandItems" @change="brandOnChageValue">
            <option v-for="(item, i) in selectBrandItems" :value="i">
              {{ item.bName }}
            </option>
          </select>
        </div>
      </el-col>
      <!--产品字段 -->
      <el-col :span="7">
        <el-input
          class="inline-input"
          v-model="formMess.fieldName"
          placeholder="选择产品字段"
          :trigger-on-focus="true"
          clearable
        >
        </el-input>
        <div class="dd">
          <select
            multiple
            v-if="productFieldItems"
            @change="productFieldOnChageValue"
          >
            <option v-for="(item, i) in productFieldItems" :value="i">
              {{ item.keyword }}
            </option>
          </select>
        </div>
      </el-col>
    </el-form>
  </div>
</template>
<script>
import {
  labelLoadData,
  sponsorLinkageSearch
} from "../../api/engineer"
export default {
  name: "relevanceBrand",
  data () {
    return {
      formMess: {
        arId: 0,
        sponsorName: null,
        bandName: null,
        fieldName: null,
        status: 2,
      },
      batchId: 0,
      selectItems: [],
      selectBrandItems: [],
      productFieldItems: [],
      search: null,
      tableData: null,
      selectSponsorIdx: 0,
      selectBrandIdx: 0,
    }
  },
  created () {
    this.batchId = this.$route.query.batchId
    this.ratio = this.$route.query.ratio
    this.getdata()
    this.SearchEngineer()
  },
  mounted () {
    this.$refs.id.$refs.input.focus()
    this.enterKeyup()
  },
  destroyed () {
    this.enterKeyupDestroyed()
  },
  methods: {
    // 搜索
    searchOnChange (e) {
      this.SearchEngineer()
    },
    // 广告主
    sponsorOnChageValue (e) {
      let idx = e.target.value
      this.selectSponsorIdx = idx
      this.formMess.sponsorName = this.selectItems[idx].adName
      this.selectBrandItems = this.selectItems[idx].brandItems
      this.productFieldItems = this.selectItems[idx].productFieldItems
      this.formMess.bandName = null
      this.formMess.fieldName = null
      this.selectSponsorIdx = 0
      this.selectBrandIdx = 0
    },
    // 品牌
    brandOnChageValue (e) {
      let idx = e.target.value
      this.formMess.bandName = this.selectBrandItems[idx].bName
      this.formMess.sponsorName = this.selectItems[this.selectSponsorIdx].adName
      this.selectBrandIdx = idx
    },
    // 产品字段
    productFieldOnChageValue (e) {
      let idx = e.target.value
      this.formMess.fieldName = this.productFieldItems[idx].keyword
      this.formMess.sponsorName = this.selectItems[this.selectSponsorIdx].adName
      this.formMess.bandName = this.selectBrandItems[this.selectBrandIdx].bName
    },
    //  数据标注(工程师)通过品牌搜索广告主关联信息
    async SearchEngineer () {
      const { data } = await sponsorLinkageSearch({ searchWords: this.formMess.bandName })
      if (data.code === 1000) {
        this.selectItems = data.data
        this.selectBrandItems = this.selectItems[0].brandItems
        this.productFieldItems = this.selectItems[0].productFieldItems
      } else {
        this.selectItems = null
        this.selectBrandItems = null
        this.productFieldItems = null
      }
      // console.log(this.selectItems)
    },
    getnull () {
      this.formMess.sponsorName = null
      this.formMess.bandName = null
      this.formMess.fieldName = null
      this.formMess.status = 2
      this.search = null
      this.selectSponsorIdx = 0
      this.selectBrandIdx = 0
    },
    //加载数据
    getdata () {
      this.getnull()
      const prames = {
        batchId: this.batchId
      }
      labelLoadData(prames).then((response) => {
        // console.log(response)
        if (response.data.code == 1000) {
          this.tableData = response.data.data
          this.formMess.arId = this.tableData.id
          // console.log(this.tableData)
        } else {
          this.$message.error(response.data.message)
        }
        //一加载获取光标焦点
        this.$refs.id.$refs.input.focus()
      })
    },
    // 绑定enter事件
    enterKeyup () {
      document.addEventListener("keyup", this.enterKey)
    },
    enterKeyupDestroyed () {
      document.removeEventListener("keyup", this.enterKey)
    },
    enterKey (event) {
      const componentName = this.$options.name
      if (componentName == "relevanceBrand") {
        const code = event.keyCode
          ? event.keyCode
          : event.which
            ? event.which
            : event.charCode
        if (code == 13) {
          // console.log(this.$parent)
          this.$emit("onSubmitttt")
        }
      }
    },
  }
}
</script>
<style lang="scss" scoped>
.rightbox {
  .formbox {
    margin-top: 20px;
  }
  .inline-input {
    display: block;
    margin-right: 10px;
    width: 200px;
  }
  // 下拉框
  select {
    margin-top: 5px;
    min-width: 200px;
    min-height: 300px;
  }
  .buttonbox {
    margin-top: 400px;
  }
}
</style>
