<template>
  <div>
    <el-form-item label="快速定位">
      <el-col :span="11">
        <el-input v-model="searchArId" placeholder="请输入资源ID"></el-input>
      </el-col>
      <el-col :span="8">
        <el-button
          type="primary"
          icon="el-icon-search"
          @click="searchQuickLocationData"
          >搜索</el-button
        >
      </el-col>
    </el-form-item>
  </div>
</template>
<script>
import { sponsorLinkageSearch } from '@/api/engineer'
export default {
  name: 'groupSearch',
  data () {
    return {

    }
  },
  methods: {
    // 快速定位
    searchQuickLocationData () {
      quickLocationData({ arId: this.searchArId, ratio: this.ratio }).then(
        (response) => {
          if (response.data.code == 1000) {
            this.tableData = response.data.data
            this.formMess.arId = this.tableData.id
            this.formMess.bandName = this.tableData.brandText
            this.formMess.fieldName = this.tableData.productFieldText
            this.formMess.sponsorName = this.tableData.sponsorText
            this.SearchEngineer()
          } else {
            this.$message.error(response.data.message)
          }
        }
      )
    },
  }
}
</script>
<style lang="scss" scoped>
</style>
