<template>
  <div>
    <!-- 组长抽检页面 -->
    <!-- 头部区域 -->
    <el-header>
      <el-row type="flex" class="header">
        应抽检<span>{{ tableData && tableData.shouldCheckCount }}</span
        >已抽检<span>{{ tableData && tableData.useCheckCount }}</span
        >张
      </el-row>
    </el-header>
    <!-- 中心主体区域 -->
    <el-container>
      <el-aside width="500px">
        <!-- 图片 -->
        <el-col :span="22">
          <div class="el-upload">
            <el-image
              class="avatar"
              :src="tableData && tableData.sourceUrl"
              :preview-src-list="[tableData && tableData.sourceUrl]"
            >
            </el-image>
          </div>
        </el-col>
      </el-aside>
      <!-- 右侧文本 -->
      <el-main class="rightbox">
        <!-- 关联区域 -->
        <div class="formbox">
          <el-form :model="formMess">
            <!--搜索 -->
            <el-form-item label="快速定位">
              <el-col :span="11">
                <el-input
                  v-model="searchArId"
                  placeholder="请输入资源ID"
                ></el-input>
              </el-col>
              <el-col :span="8">
                <el-button
                  type="primary"
                  icon="el-icon-search"
                  @click="searchQuickLocationData"
                  >搜索</el-button
                >
              </el-col>
            </el-form-item>

            <!-- 品牌关联 -->
            <relevance-brand
              ref="guanggao"
              @onSubmitttt="onSubmit"
            ></relevance-brand>
          </el-form>
        </div>
        <!-- button区域 -->
        <div class="buttonbox">
          <span>
            <el-button
              type="success"
              size="mini"
              @keyup.enter="onSubmit"
              @click="onSubmit"
              round
              >提交</el-button
            ></span
          >
          <span>
            <el-button type="primary" size="mini" @click="onSave" round
              >通过</el-button
            ></span
          >
          <span>
            <el-button type="danger" size="mini" @click="onUnconfirm" round
              >不通过</el-button
            >
          </span>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
// 组长提交数据
import { submitData } from '@/api/GroupLeader'
// 获取组长抽检数据
import { drawlots, quickLocationData, submitChangeData } from '@/api/GroupLeader'
import { sponsorLinkageSearch } from '@/api/engineer'
// 导入关联品牌组件
import relevanceBrand from '@/components/relevancebrand'

export default {
  name: 'GroupLeaderSpotCheckmainform',
  components: { relevanceBrand },
  data () {
    return {
      formMess: {
        arId: '',
        sponsorName: null,
        bandName: null,
        fieldName: null,
        isPass: 0,
      },
      tableData: [],
      batchId: 0,
      ratio: 0,
      searchArId: null,
      search: null,
      selectItems: [],
      selectBrandItems: [],
      productFieldItems: [],
      selectSponsorIdx: 0,
      selectBrandIdx: 0,
    }
  },


  methods: {
    getnull () {
      this.formMess.isPass = 0
      this.selectSponsorIdx = 0
      this.selectBrandIdx = 0
      this.searchArId = null
    },

    // 快速定位
    searchQuickLocationData () {
      quickLocationData({ arId: this.searchArId, ratio: this.ratio }).then(
        (response) => {
          if (response.data.code == 1000) {
            this.tableData = response.data.data
            this.formMess.arId = this.tableData.id
            this.formMess.bandName = this.tableData.brandText
            this.formMess.fieldName = this.tableData.productFieldText
            this.formMess.sponsorName = this.tableData.sponsorText
            this.SearchEngineer()
          } else {
            this.$message.error(response.data.message)
          }
        }
      )
    },
    //加载数据
    getdata () {
      drawlots({ batchId: this.batchId, ratio: this.ratio }).then(
        (response) => {
          if (response.data.code == 1000) {
            this.tableData = response.data.data
            this.$refs.guanggao.formMess.arId = this.tableData.id
            this.$refs.guanggao.formMess.bandName = this.tableData.brandText
            this.$refs.guanggao.formMess.fieldName = this.tableData.productFieldText
            this.$refs.guanggao.formMess.sponsorName = this.tableData.sponsorText
            this.searchArId = null
          } else {
            this.$message.error(response.data.message)
          }
        }
      )
    },
    // 提交
    onSubmit () {
      submitChangeData(this.$refs.guanggao.formMess).then((response) => {
        if (response.data.code == 1000) {
          this.getdata()
        } else {
          this.$message.error(response.data.message)
        }
        this.resetFormMess()
      })
    },
    // 不通过
    onUnconfirm () {
      this.$refs.guanggao.formMesss.isPass = 1
      submitData(this.$refs.guanggao.formMess.formMess).then((response) => {
        if (response.data.code == 1000) {
          this.getdata()
        } else {
          this.$message.error(response.data.message)
        }
        this.resetFormMess()
      })
    },
    // 通过
    onSave () {
      this.$refs.guanggao.formMess.isPass = 2
      submitData(this.$refs.guanggao.formMess).then((response) => {
        if (response.data.code == 1000) {
          this.getdata()
        } else {
          this.$message.error(response.data.message)
        }
        this.resetFormMess()
      })
    },
    // 设置导入组件
    resetFormMess () {
      this.$refs.guanggao.formMess.sponsorName = this.$refs.guanggao.formMess.bandName = this.$refs.guanggao.formMess.fieldName = ''
      this.$refs.guanggao.$refs.id.focus()
    }
  },
}
</script>

<style lang="scss" scoped>
.el-button--mini,
.el-button--mini.is-round {
  padding: 9px 60px;
}
.el-header {
  background-color: #b3c0d1;
  color: #333;
  font-size: 20px;
  line-height: 60px;
  span {
    color: red;
  }
}
// 这是上传图片父容器。
.el-upload {
  margin-top: 30px;
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  position: relative;
  overflow: hidden;
  display: flex;
  justify-content: space-around;
  align-items: center;
  max-width: 650px;
  max-height: 800px;
  // 上传图片子容器
  .avatar {
    max-width: 600px;
    max-height: 750px;
    width: 100%;
    height: 100%;
    display: block;
  }
}
.buttonbox {
  margin-top: 400px;
}
</style>
