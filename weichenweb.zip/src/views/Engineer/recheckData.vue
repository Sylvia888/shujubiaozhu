<template>
  <div>
    <!-- 工程师数据复核页面 -->
    <!-- 头部区域 -->
    <el-header>
      <el-row type="flex" class="header">
        批次总数量<span>{{ tableData ? tableData.batchTotalCount : 0 }}</span
        >需要复核数量<span>{{
          tableData ? tableData.reCheckTotalCount : 0
        }}</span>
      </el-row>
    </el-header>
    <!-- 中心主体区域 -->
    <el-container>
      <div>
        <!-- 图片 -->
        <el-col :span="22">
          <div class="el-upload">
            <el-image
              class="avatar"
              :src="tableData && tableData.sourceUrl"
              :preview-src-list="[tableData && tableData.sourceUrl]"
            >
            </el-image>
          </div>
        </el-col>
      </div>
      <!-- 右侧文本 -->
      <div class="rightbox">
        <!-- 关联区域 -->
        <relevance-brand
          ref="guanggao"
          @onSubmitttt="onSubmit"
        ></relevance-brand>
        <!-- button区域 -->
        <div class="buttonbox">
          <span>
            <el-button
              type="primary"
              size="mini"
              @keyup.enter="onSubmit"
              @click="onSubmit"
              round
              >提交</el-button
            >
          </span>
          <span>
            <el-button type="info" size="mini" @click="noAdvSubmit" round
              >无广告主</el-button
            ></span
          >
          <span>
            <el-button
              type="warning"
              size="mini"
              @click="cannottellSubmit"
              round
              >无法判断
            </el-button>
          </span>
        </div>
      </div>
    </el-container>
  </div>
</template>

<script>
import 'viewerjs/dist/viewer.css'
import axios from 'axios'
import { mapGetters } from 'vuex'
// 导入关联品牌组件
import relevanceBrand from '@/components/relevancebrand'
import {
  getReCheckDataList,
  searchSponsorName,
  searchBandsName,
  searchProductFields,
  reCheckSubmitOperate,
  sponsorLinkageSearch,
} from '../../api/engineer'

import {
  fetchMsdsList,
  fetchChemicalsTypes,
  addMsdsBaseInfo,
  updateMsdsBaseInfo,
  addMsdsEmergencyDisposal,
  updateMsdsEmergencyDisposal,
  addFirstAidMeasures,
  updateFirstAidMeasures,
  importExcel,
  delMsds,
} from '@/api/msds'

export default {
  name: 'EngineerrecheckData',
  components: { relevanceBrand },
  data () {
    return {
      batchId: 0,
      selectItems: [],
      selectBrandItems: [],
      productFieldItems: [],
      search: null,
      tableData: null,
      selectSponsorIdx: 0,
      selectBrandIdx: 0,
    }
  },
  created () {
    this.batchId = this.$route.query.batchId
    this.getdata()
  },
  methods: {
    getnull () {
      this.search = null
      this.selectSponsorIdx = 0
      this.selectBrandIdx = 0
    },
    //加载数据
    getdata () {
      this.getnull()
      const prames = {
        batchId: this.batchId,
      }
      // 获取复核数据
      getReCheckDataList(prames).then((response) => {
        if (response.data.code == 1000) {
          this.tableData = response.data.data
          this.$refs.guanggao.formMess.arId = this.tableData.id
          this.$refs.guanggao.formMess.bandName = this.tableData.brandText
          this.$refs.guanggao.formMess.fieldName = this.tableData.productFieldText
          this.$refs.guanggao.formMess.sponsorName = this.tableData.sponsorText
        } else {
          this.$message.error(response.data.message)
        }
        //一加载获取光标焦点
        // this.$refs.id.$refs.input.focus()
      })
    },
    // reStatus 复核状态  0 不需复核 1待复核 2已提交（有广告主）3无广告主 4无法判断
    //提交
    onSubmit: function () {
      this.$refs.guanggao.formMess.status = 2
      reCheckSubmitOperate(this.$refs.guanggao.formMess).then((response) => {
        if (response.data.code == 1000) {
          this.getdata()
        } else {
          this.$message.error(response.data.message)
        }
        this.resetFormMess()
      })
    },
    // 无广告提交
    noAdvSubmit () {
      this.$refs.guanggao.formMess.status = 3
      reCheckSubmitOperate(this.$refs.guanggao.formMess).then((response) => {
        if (response.data.code == 1000) {
          this.getdata()
        } else {
          this.$message.error(response.data.message)
        }
        this.resetFormMess()
      })
    },
    // 无法判断
    cannottellSubmit () {
      this.$refs.guanggao.formMess.status = 4
      reCheckSubmitOperate(this.$refs.guanggao.formMess.status).then((response) => {
        if (response.data.code == 1000) {
          this.getdata()
        } else {
          this.$message.error(response.data.message)
        }
        this.resetFormMess()
      })
    },
    resetFormMess () {
      this.$refs.guanggao.formMess.sponsorName = this.$refs.guanggao.formMess.bandName = this.$refs.guanggao.formMess.fieldName = ''
      this.$refs.guanggao.$refs.id.focus()
    }
  },
}
</script>

<style lang="scss" scoped>
.el-button--mini,
.el-button--mini.is-round {
  padding: 9px 60px;
}
.el-header {
  background-color: #b3c0d1;
  color: #333;
  font-size: 20px;
  line-height: 60px;
  span {
    color: red;
  }
}
// 这是上传图片父容器。
.el-upload {
  margin-top: 30px;
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  position: relative;
  overflow: hidden;
  display: flex;
  justify-content: space-around;
  align-items: center;
  max-width: 650px;
  max-height: 800px;
  // 上传图片子容器
  .avatar {
    max-width: 600px;
    max-height: 750px;
    width: 100%;
    height: 100%;
    display: block;
  }
}
.buttonbox {
  margin-top: 400px;
}
</style>
