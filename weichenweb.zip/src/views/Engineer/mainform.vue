<template>
  <div>
    <!-- 工程师数据标注页面 -->
    <!-- 头部区域 -->
    <el-header>
      <el-row type="flex" class="header">
        总数量<span>{{ tableData ? tableData.batchTotalCount : 0 }}</span
        >共标注<span>{{ tableData ? tableData.markedTotalCount : 0 }}</span
        >我的标注数量<span>{{ tableData ? tableData.iMarkedCount : 0 }}</span>
      </el-row>
    </el-header>
    <!-- 中心主体区域 -->
    <el-container>
      <div>
        <!-- 图片 -->
        <el-col :span="22">
          <div class="el-upload">
            <el-image
              class="avatar"
              :src="tableData && tableData.sourceUrl"
              :preview-src-list="[tableData && tableData.sourceUrl]"
            >
            </el-image>
          </div>
        </el-col>
      </div>
      <!-- 右侧文本 -->
      <el-main class="rightbox">
        <!-- 关联区域 -->
        <relevance-brand
          ref="guanggao"
          @onSubmitttt="onSubmit"
        ></relevance-brand>
        <!-- button区域 -->
        <div class="buttonbox">
          <span>
            <el-button
              type="primary"
              size="mini"
              @keyup.enter="onSubmit"
              @click="onSubmit"
              round
              >提交</el-button
            >
          </span>
          <span>
            <el-button type="info" size="mini" @click="unconfirmSubmit" round
              >待确认</el-button
            >
          </span>
          <span>
            <el-button type="warning" size="mini" @click="noAdvSubmit" round
              >无广告主
            </el-button>
          </span>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import "viewerjs/dist/viewer.css"
import axios from "axios"
import { mapGetters } from "vuex"
import pagination from "@/components/Pagination"
import ImageViewer from '@/components/Wcimage/ImageViewer'
// 导入关联品牌组件
import relevanceBrand from '@/components/relevancebrand'
//
import {
  labelLoadData,
  searchSponsorName,
  searchBandsName,
  searchProductFields,
  submitData,
  sponsorLinkageSearch
} from "../../api/engineer"

import {
  fetchMsdsList,
  fetchChemicalsTypes,
  addMsdsBaseInfo,
  updateMsdsBaseInfo,
  addMsdsEmergencyDisposal,
  updateMsdsEmergencyDisposal,
  addFirstAidMeasures,
  updateFirstAidMeasures,
  importExcel,
  delMsds,
} from "@/api/msds"

export default {
  name: "EngineerMainForm",
  components: { relevanceBrand },
  data () {
    return {
      batchId: 0,
      selectItems: [],
      selectBrandItems: [],
      productFieldItems: [],
      search: null,
      tableData: null,
      selectSponsorIdx: 0,
      selectBrandIdx: 0,
    }
  },
  created () {
    this.batchId = this.$route.query.batchId
    this.getdata()
  },
  methods: {
    getnull () {
      this.search = null
      this.selectSponsorIdx = 0
      this.selectBrandIdx = 0
    },
    //加载数据
    getdata () {
      this.getnull()
      const prames = {
        batchId: this.batchId
      }
      labelLoadData(prames).then((response) => {
        // console.log(response)
        if (response.data.code == 1000) {
          this.tableData = response.data.data
          this.$refs.guanggao.formMess.arId = this.tableData.id
          // console.log(this.tableData)
        } else {
          this.$message.error(response.data.message)
        }
      })
    },
    //待确认    	1待确认 2已提交（有广告主） 3无广告主
    unconfirmSubmit () {
      this.$refs.guanggao.formMess.status = 1
      // 数据标注（工程师）提交标注操作
      submitData(this.$refs.guanggao.formMess).then((response) => {
        if (response.data.code == 1000) {
          this.getdata()
          this.$message.success('待确认成功')
        } else {
          this.$message.error(response.data.message)
        }
        this.resetFormMess()
      })
    },
    //提交
    onSubmit: function () {
      this.$refs.guanggao.formMess.status = 2
      submitData(this.$refs.guanggao.formMess).then((response) => {
        if (response.data.code == 1000) {
          this.getdata()
          this.$message.success('提交成功')
        } else {
          this.$message.error(response.data.message)
        }
        this.resetFormMess()
      })
    },
    // 无广告提交
    noAdvSubmit () {
      this.$refs.guanggao.formMess.status = 3
      submitData(this.$refs.guanggao.formMess).then((response) => {
        if (response.data.code == 1000) {
          this.getdata()
          this.$message.success('无广告提交成功')
        } else {
          this.$message.error(response.data.message)
        }
        this.resetFormMess()
      })
    },
    resetFormMess () {
      this.$refs.guanggao.formMess.sponsorName = this.$refs.guanggao.formMess.bandName = this.$refs.guanggao.formMess.fieldName = ''
      this.$refs.guanggao.$refs.id.focus()
    }
  },

};
</script>

<style lang="scss" scoped>
.el-button--mini,
.el-button--mini.is-round {
  padding: 9px 60px;
}
.el-header {
  background-color: #b3c0d1;
  color: #333;
  font-size: 20px;
  line-height: 60px;
  span {
    color: red;
  }
}
// 这是上传图片父容器。
.el-upload {
  margin-top: 30px;
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  position: relative;
  overflow: hidden;
  display: flex;
  justify-content: space-around;
  align-items: center;
  max-width: 650px;
  max-height: 800px;
  // 上传图片子容器
  .avatar {
    max-width: 600px;
    max-height: 750px;
    width: 100%;
    height: 100%;
    display: block;
  }
}
.buttonbox {
  margin-top: 400px;
}
</style>
